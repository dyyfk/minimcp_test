# MiniMCP RTCA 2026 - lean Overleaf project

Main document: main.tex. Compiler: pdfLaTeX; TeX Live 2026; Normal mode.

All TeX, bibliography and style files match the Git checkout used to build
this package. Complete paper text and appendix are retained. Unused files,
scripts and the compiled reference PDF are omitted. Included PNG plots
with extension-free references use lossless PDF containers: original
pixels, no resampling, no JPEG compression. Existing PDF figures and
font repairs are unchanged.

Rebuild after source edits with build_overleaf_zip.py in the repository.
Tectonic and pdfLaTeX can produce different pagination; compare versions
using the same engine. The smaller package does not guarantee that every
compile stays below Overleaf's free-plan timeout.
